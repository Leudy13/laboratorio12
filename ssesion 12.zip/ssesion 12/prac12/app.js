function sumarNumeros(){ 
   //parte 1: calcular suma y promedio con entrada de usuario 
  
    const entrada = document.getElementById('promedio').value;
    const numeros = entrada.split(',').map(num => parseFloat(num.trim()));
    // let numeros=[10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
    let suma = 0;

    for ( let i = 0; i < numeros. length; i++){
        if (!isNaN( numeros [i])) {  
            suma = suma +numeros[i]
        }
    }
const promedio = suma / numeros.length;
document.getElementById('salidaPromedio').innerText = `suma total: ${suma.toFixed(1)}, promedio: ${promedio.toFixed(1)}`;

}

function ingresarNumeros(){
    let numeroIngresado = [];
    let suma = 0;
    let numero=1;

    while (numero >= 0){
        numero= parseFloat(prompt("ingresa un numero (negativo para terminar):"));
        if(numero>=0){
            if (!isNaN(numero)){
                numeroIngresado.push(numero);
                suma = suma + numero;
        }
       
        }
    }
document.getElementById('salidaNumeros').innerHTML=`<strong>Numeros ingresados:</strong> ${numeroIngresado.join(',')}<br>
<strong>suma total:</strong> ${suma}`;

}

function validarContrasena(){
    const contrasenacorrecta = "1234";
    let intentos = 0;
    let contrasena;
    let contrasenaingresadas = [];
 do {
    contrasena = prompt ("ingresa la contraseña:");
    contrasenaingresadas.push(contrasena);
    intentos=intentos+1;
    if (contrasena !== contrasenacorrecta){
        alert("contraseña incorrecta")
    }

} while (contrasena !== contrasenacorrecta);

document.getElementById(`salidaContrasena`).innerHTML = `<strong>¡contraseña correcta!</strong><br>
<strong>intento fallido:</strong> ${intentos-1}<br>
<strong>contraseña ingresada:</strong> ${contrasenaingresadas.join(',')}`;
}
